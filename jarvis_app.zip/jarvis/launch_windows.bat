@echo off
title J.A.R.V.I.S. Launcher
color 0B
echo.
echo  ╔═══════════════════════════════════════════════╗
echo  ║        J.A.R.V.I.S.  INITIALIZING...         ║
echo  ║   Just A Rather Very Intelligent System       ║
echo  ╚═══════════════════════════════════════════════╝
echo.

:: Check Python
python --version >nul 2>&1
if errorlevel 1 (
    echo  [ERROR] Python not found. Install from https://python.org
    pause
    exit /b 1
)

echo  [OK] Python detected.

:: Install dependencies
echo  [..] Installing dependencies...
pip install -r requirements.txt --quiet
echo  [OK] Dependencies ready.

echo.
echo  [>>] Launching J.A.R.V.I.S...
echo.

python jarvis.py
pause
