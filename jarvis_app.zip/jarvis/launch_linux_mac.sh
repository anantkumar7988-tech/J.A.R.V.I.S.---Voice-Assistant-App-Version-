#!/bin/bash

echo ""
echo " ╔═══════════════════════════════════════════════╗"
echo " ║        J.A.R.V.I.S.  INITIALIZING...         ║"
echo " ║   Just A Rather Very Intelligent System       ║"
echo " ╚═══════════════════════════════════════════════╝"
echo ""

# Check Python
if ! command -v python3 &> /dev/null; then
    echo " [ERROR] Python3 not found. Install via your package manager."
    exit 1
fi

echo " [OK] Python3 detected: $(python3 --version)"

# Check tkinter
python3 -c "import tkinter" 2>/dev/null
if [ $? -ne 0 ]; then
    echo " [..] Installing tkinter..."
    sudo apt-get install -y python3-tk 2>/dev/null || brew install python-tk 2>/dev/null
fi

# Install pip deps
echo " [..] Installing Python dependencies..."
pip3 install -r requirements.txt --quiet 2>/dev/null || pip install -r requirements.txt --quiet

# pyaudio on Linux needs portaudio
if command -v apt-get &> /dev/null; then
    sudo apt-get install -y portaudio19-dev python3-pyaudio 2>/dev/null
elif command -v brew &> /dev/null; then
    brew install portaudio 2>/dev/null
fi

echo " [OK] All dependencies ready."
echo ""
echo " [>>] Launching J.A.R.V.I.S..."
echo ""

python3 jarvis.py
