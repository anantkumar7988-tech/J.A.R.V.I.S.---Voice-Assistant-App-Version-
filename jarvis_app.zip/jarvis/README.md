# ◈ J.A.R.V.I.S.
### Just A Rather Very Intelligent System
**A Python-based voice AI desktop assistant with an Iron Man HUD interface**

---

## ⚡ QUICK START

### Windows
```
Double-click: launch_windows.bat
```

### Linux / macOS
```bash
chmod +x launch_linux_mac.sh
./launch_linux_mac.sh
```

### Manual
```bash
pip install -r requirements.txt
python jarvis.py
```

---

## 📦 REQUIREMENTS

| Package | Purpose |
|---|---|
| `pyttsx3` | Text-to-speech (voice responses) |
| `SpeechRecognition` | Voice input |
| `pyaudio` | Microphone access |
| `psutil` | CPU/RAM/Disk monitoring |
| `requests` | Weather & IP lookup |
| `wikipedia` | Wikipedia search |
| `Pillow` | Screenshot capture |

> **Note:** All packages are optional. JARVIS works in text-only mode if voice packages are missing.

### Python Version
Requires **Python 3.8+**. Download: https://python.org

### pyaudio on Linux
```bash
sudo apt install portaudio19-dev python3-pyaudio
```

### pyaudio on macOS
```bash
brew install portaudio
pip install pyaudio
```

---

## 🗣 VOICE COMMANDS

| Command | Action |
|---|---|
| `What time is it?` | Current time |
| `What's today's date?` | Current date |
| `What is 256 * 48?` | Calculator |
| `Open Google` | Opens browser |
| `Open YouTube` | Opens YouTube |
| `Open Notepad` | Opens text editor |
| `Open Calculator` | Opens system calculator |
| `Open Terminal` | Opens terminal/cmd |
| `Search for Python tutorials` | Google search |
| `Play Lo-fi music` | YouTube search |
| `Weather in Mumbai` | Weather report |
| `Tell me about black holes` | Wikipedia lookup |
| `System status` | CPU/RAM/Disk info |
| `My IP address` | Public IP |
| `Take a screenshot` | Saves screenshot |
| `Tell me a joke` | Random joke |
| `Productivity tip` | Work advice |
| `What can you do?` | Full command list |
| `Goodbye` | Exit JARVIS |

---

## 🎨 INTERFACE

- **Iron Man HUD** aesthetic — deep space blue + electric cyan
- **Animated orbital core** with rotating rings and pulsing glow
- **Real-time system monitor** — CPU, RAM, Disk usage bars
- **Full conversation log** with color-coded message types
- **Input history** — press ↑/↓ to cycle previous commands
- **Quick Access** sidebar with one-click commands
- **Status bar** showing current JARVIS state
- **Live clock** in header

---

## 🔧 TROUBLESHOOTING

**"No module named 'tkinter'"** (Linux)
```bash
sudo apt install python3-tk
```

**Voice not working**
- Ensure microphone is connected and allowed
- Install: `pip install SpeechRecognition pyaudio`
- On Linux: `sudo apt install portaudio19-dev`

**TTS not working**
```bash
pip install pyttsx3
# On Linux also: sudo apt install espeak
```

**Wikipedia not working**
```bash
pip install wikipedia
```

---

## 📁 FILES

```
jarvis/
├── jarvis.py              ← Main application
├── requirements.txt       ← Python dependencies
├── launch_windows.bat     ← Windows launcher
├── launch_linux_mac.sh    ← Linux/macOS launcher
└── README.md              ← This file
```

---

*J.A.R.V.I.S. — Built with Python & tkinter. No API keys required.*
