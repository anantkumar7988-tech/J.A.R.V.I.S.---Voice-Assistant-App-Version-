"""
╔══════════════════════════════════════════════════════════╗
║          J.A.R.V.I.S  —  Voice AI Assistant             ║
║     Just A Rather Very Intelligent System               ║
╚══════════════════════════════════════════════════════════╝
"""

import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox
import threading
import datetime
import math
import time
import os
import sys
import random
import subprocess
import webbrowser
import json
import re

# ── Optional imports (gracefully handled) ────────────────────────────────────
try:
    import pyttsx3
    TTS_AVAILABLE = True
except ImportError:
    TTS_AVAILABLE = False

try:
    import speech_recognition as sr
    SR_AVAILABLE = True
except ImportError:
    SR_AVAILABLE = False

try:
    import psutil
    PSUTIL_AVAILABLE = True
except ImportError:
    PSUTIL_AVAILABLE = False

try:
    import requests
    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False

try:
    import wikipedia
    WIKI_AVAILABLE = True
except ImportError:
    WIKI_AVAILABLE = False


# ══════════════════════════════════════════════════════════════════════════════
#  DESIGN CONSTANTS — Iron Man HUD aesthetic
# ══════════════════════════════════════════════════════════════════════════════
BG          = "#050810"
BG2         = "#080d1a"
PANEL       = "#0a1020"
BORDER      = "#1a2a4a"
ACCENT      = "#00d4ff"      # electric cyan
ACCENT2     = "#0088cc"
ACCENT_DIM  = "#003355"
RED         = "#ff3030"
GREEN       = "#00ff88"
YELLOW      = "#ffcc00"
TEXT        = "#c8e8ff"
TEXT_DIM    = "#4a6a8a"
TEXT_MUTED  = "#2a4060"
FONT_MAIN   = ("Consolas", 11)
FONT_TITLE  = ("Consolas", 22, "bold")
FONT_SUB    = ("Consolas", 9)
FONT_CHAT   = ("Consolas", 10)
FONT_MONO   = ("Consolas", 10)
FONT_BIG    = ("Consolas", 14, "bold")


# ══════════════════════════════════════════════════════════════════════════════
#  BRAIN — Command Processing
# ══════════════════════════════════════════════════════════════════════════════
class JarvisBrain:
    def __init__(self):
        self.tts_engine = None
        self.recognizer = None
        self.mic = None
        self.voice_enabled = True
        self.is_speaking = False
        self.conversation_history = []
        self._init_tts()
        self._init_sr()

    def _init_tts(self):
        if not TTS_AVAILABLE:
            return
        try:
            self.tts_engine = pyttsx3.init()
            voices = self.tts_engine.getProperty('voices')
            # Prefer a male voice for Jarvis feel
            for v in voices:
                if 'male' in v.name.lower() or 'david' in v.name.lower() or 'mark' in v.name.lower():
                    self.tts_engine.setProperty('voice', v.id)
                    break
            self.tts_engine.setProperty('rate', 185)
            self.tts_engine.setProperty('volume', 0.95)
        except Exception:
            self.tts_engine = None

    def _init_sr(self):
        if not SR_AVAILABLE:
            return
        try:
            self.recognizer = sr.Recognizer()
            self.recognizer.energy_threshold = 3000
            self.recognizer.pause_threshold = 0.8
            self.recognizer.dynamic_energy_threshold = True
            self.mic = sr.Microphone()
            # Calibrate in background
            threading.Thread(target=self._calibrate_mic, daemon=True).start()
        except Exception:
            self.recognizer = None

    def _calibrate_mic(self):
        try:
            with self.mic as source:
                self.recognizer.adjust_for_ambient_noise(source, duration=1)
        except Exception:
            pass

    def speak(self, text):
        if not self.voice_enabled or not self.tts_engine:
            return
        def _speak():
            self.is_speaking = True
            try:
                self.tts_engine.say(text)
                self.tts_engine.runAndWait()
            except Exception:
                pass
            self.is_speaking = False
        threading.Thread(target=_speak, daemon=True).start()

    def stop_speaking(self):
        if self.tts_engine:
            try:
                self.tts_engine.stop()
            except Exception:
                pass
        self.is_speaking = False

    def listen(self, callback_partial, callback_final, callback_error):
        """Listen once and return transcript"""
        if not self.recognizer or not self.mic:
            callback_error("Speech recognition not available. Install: pip install SpeechRecognition pyaudio")
            return
        def _listen():
            try:
                callback_partial("Calibrating...")
                with self.mic as source:
                    callback_partial("Listening... (speak now)")
                    audio = self.recognizer.listen(source, timeout=8, phrase_time_limit=10)
                callback_partial("Processing speech...")
                text = self.recognizer.recognize_google(audio)
                callback_final(text)
            except sr.WaitTimeoutError:
                callback_error("No speech detected. Try again.")
            except sr.UnknownValueError:
                callback_error("Could not understand audio. Please speak clearly.")
            except sr.RequestError:
                callback_error("Speech service unavailable. Check internet connection.")
            except Exception as e:
                callback_error(f"Error: {str(e)}")
        threading.Thread(target=_listen, daemon=True).start()

    def process(self, text):
        """Main command processor — returns (response_text, action)"""
        t = text.lower().strip()
        now = datetime.datetime.now()

        # ── Time & Date ──────────────────────────────────────────────────────
        if any(w in t for w in ['time', 'clock']):
            return (f"The current time is {now.strftime('%I:%M:%S %p')}.", "info")

        if any(w in t for w in ['date', 'today', 'day of the week']):
            return (f"Today is {now.strftime('%A, %B %d, %Y')}.", "info")

        if 'year' in t:
            return (f"It is currently the year {now.year}.", "info")

        # ── Math / Calculator ────────────────────────────────────────────────
        math_triggers = ['calculate', 'compute', 'what is', 'what\'s', 'solve', 'evaluate', '=?']
        if any(tr in t for tr in math_triggers) or re.search(r'[\d]+[\s]*[\+\-\*\/\^][\s]*[\d]+', t):
            expr = re.sub(r'(calculate|compute|what is|what\'s|solve|evaluate|please)', '', t).strip()
            expr = expr.replace('^', '**').replace('x', '*').replace('×', '*').replace('÷', '/')
            expr = re.sub(r'[^\d\+\-\*\/\.\(\)\s\*]', '', expr).strip()
            if expr:
                try:
                    result = eval(expr, {"__builtins__": {}}, {})
                    return (f"{expr} = {result}", "calc")
                except Exception:
                    pass

        # ── Open Apps / Programs ─────────────────────────────────────────────
        if 'open notepad' in t or 'notepad' in t:
            try:
                subprocess.Popen('notepad.exe')
                return ("Opening Notepad.", "action")
            except Exception:
                try:
                    subprocess.Popen(['gedit'])
                    return ("Opening text editor.", "action")
                except Exception:
                    return ("Could not open text editor on this system.", "error")

        if 'open calculator' in t or ('calculator' in t and 'open' in t):
            try:
                subprocess.Popen('calc.exe')
                return ("Opening Calculator.", "action")
            except Exception:
                try:
                    subprocess.Popen(['gnome-calculator'])
                    return ("Opening Calculator.", "action")
                except Exception:
                    return ("Calculator app not found. I can calculate here — just ask.", "info")

        if 'open file manager' in t or 'file explorer' in t or 'explorer' in t:
            try:
                subprocess.Popen('explorer.exe')
                return ("Opening File Explorer.", "action")
            except Exception:
                try:
                    subprocess.Popen(['nautilus'])
                    return ("Opening File Manager.", "action")
                except Exception:
                    return ("Could not open file manager.", "error")

        if 'open terminal' in t or 'command prompt' in t or 'cmd' in t:
            try:
                subprocess.Popen('cmd.exe')
                return ("Opening Command Prompt.", "action")
            except Exception:
                try:
                    subprocess.Popen(['gnome-terminal'])
                    return ("Opening Terminal.", "action")
                except Exception:
                    return ("Could not open terminal.", "error")

        if 'open paint' in t:
            try:
                subprocess.Popen('mspaint.exe')
                return ("Opening Paint.", "action")
            except Exception:
                return ("Paint is not available on this system.", "error")

        if 'task manager' in t:
            try:
                subprocess.Popen('taskmgr.exe')
                return ("Opening Task Manager.", "action")
            except Exception:
                return ("Task Manager not available on this system.", "error")

        # ── Web / Browser ────────────────────────────────────────────────────
        if 'open google' in t:
            webbrowser.open('https://google.com')
            return ("Opening Google.", "action")

        if 'open youtube' in t:
            webbrowser.open('https://youtube.com')
            return ("Opening YouTube.", "action")

        if 'open github' in t:
            webbrowser.open('https://github.com')
            return ("Opening GitHub.", "action")

        if 'open reddit' in t:
            webbrowser.open('https://reddit.com')
            return ("Opening Reddit.", "action")

        if 'open twitter' in t or 'open x' in t:
            webbrowser.open('https://x.com')
            return ("Opening X (Twitter).", "action")

        if 'open instagram' in t:
            webbrowser.open('https://instagram.com')
            return ("Opening Instagram.", "action")

        if 'open netflix' in t:
            webbrowser.open('https://netflix.com')
            return ("Opening Netflix.", "action")

        if 'open spotify' in t:
            webbrowser.open('https://open.spotify.com')
            return ("Opening Spotify.", "action")

        if 'open wikipedia' in t:
            webbrowser.open('https://wikipedia.org')
            return ("Opening Wikipedia.", "action")

        # Search web
        search_match = re.search(r'(?:search|google|look up|find)\s+(?:for\s+)?(.+)', t)
        if search_match:
            query = search_match.group(1).strip()
            webbrowser.open(f"https://www.google.com/search?q={query.replace(' ', '+')}")
            return (f'Searching Google for "{query}".', "action")

        # Search YouTube
        yt_match = re.search(r'(?:play|youtube|watch)\s+(.+)', t)
        if yt_match:
            query = yt_match.group(1).strip()
            webbrowser.open(f"https://www.youtube.com/results?search_query={query.replace(' ', '+')}")
            return (f'Searching YouTube for "{query}".', "action")

        # ── Wikipedia ────────────────────────────────────────────────────────
        wiki_match = re.search(r'(?:tell me about|what is|who is|explain|define)\s+(.+)', t)
        if wiki_match and WIKI_AVAILABLE:
            query = wiki_match.group(1).strip()
            try:
                summary = wikipedia.summary(query, sentences=3)
                return (summary, "wiki")
            except wikipedia.exceptions.DisambiguationError as e:
                return (f"Multiple results for '{query}'. Try: {', '.join(e.options[:3])}", "info")
            except Exception:
                webbrowser.open(f"https://en.wikipedia.org/w/index.php?search={query.replace(' ', '+')}")
                return (f"Opened Wikipedia search for '{query}'.", "action")

        # ── System Info ──────────────────────────────────────────────────────
        if any(w in t for w in ['system', 'cpu', 'ram', 'memory', 'disk', 'battery', 'pc info', 'computer']):
            if PSUTIL_AVAILABLE:
                info_parts = []
                try:
                    cpu = psutil.cpu_percent(interval=0.5)
                    info_parts.append(f"CPU: {cpu}%")
                except Exception:
                    pass
                try:
                    ram = psutil.virtual_memory()
                    info_parts.append(f"RAM: {ram.percent}% used ({round(ram.used/1e9,1)}GB / {round(ram.total/1e9,1)}GB)")
                except Exception:
                    pass
                try:
                    disk = psutil.disk_usage('/')
                    info_parts.append(f"Disk: {disk.percent}% used ({round(disk.used/1e9,1)}GB / {round(disk.total/1e9,1)}GB)")
                except Exception:
                    pass
                try:
                    battery = psutil.sensors_battery()
                    if battery:
                        status = "charging" if battery.power_plugged else "on battery"
                        info_parts.append(f"Battery: {round(battery.percent)}% ({status})")
                except Exception:
                    pass
                if info_parts:
                    return ("System Status — " + " | ".join(info_parts), "system")
            return ("System monitoring requires psutil. Run: pip install psutil", "error")

        if 'ip address' in t or 'my ip' in t:
            if REQUESTS_AVAILABLE:
                try:
                    ip = requests.get('https://api.ipify.org', timeout=3).text
                    return (f"Your public IP address is {ip}.", "info")
                except Exception:
                    return ("Could not retrieve IP address. Check internet connection.", "error")
            return ("requests library not installed. Run: pip install requests", "error")

        # ── Weather ──────────────────────────────────────────────────────────
        if 'weather' in t:
            city_match = re.search(r'weather(?:\s+in\s+|\s+for\s+|\s+of\s+)(.+)', t)
            city = city_match.group(1).strip() if city_match else None
            if REQUESTS_AVAILABLE and city:
                try:
                    url = f"https://wttr.in/{city.replace(' ', '+')}?format=3"
                    resp = requests.get(url, timeout=4)
                    if resp.status_code == 200:
                        return (f"Weather: {resp.text.strip()}", "info")
                except Exception:
                    pass
            if city:
                webbrowser.open(f"https://www.google.com/search?q=weather+{city.replace(' ', '+')}")
                return (f"Opened weather for {city} in browser.", "action")
            webbrowser.open("https://www.google.com/search?q=weather+today")
            return ("Opened weather in browser.", "action")

        # ── News ─────────────────────────────────────────────────────────────
        if 'news' in t:
            webbrowser.open('https://news.google.com')
            return ("Opening Google News in browser.", "action")

        # ── Jokes ────────────────────────────────────────────────────────────
        if any(w in t for w in ['joke', 'funny', 'laugh', 'humor']):
            jokes = [
                "Why do programmers prefer dark mode? Because light attracts bugs!",
                "I told my computer I needed a break. Now it won't stop sending me Kit-Kat ads.",
                "Why was the developer so calm? Because they had good version control.",
                "A SQL query walks into a bar, walks up to two tables and asks... 'Can I join you?'",
                "Why do Java developers wear glasses? Because they don't C#!",
                "There are only 10 types of people: those who understand binary and those who don't.",
                "How many programmers does it take to change a lightbulb? None — that's a hardware problem.",
                "Why did the computer show up late? It had a hard drive.",
            ]
            return (random.choice(jokes), "fun")

        # ── Productivity Tips ────────────────────────────────────────────────
        if any(w in t for w in ['tip', 'productivity', 'advice', 'motivate', 'focus']):
            tips = [
                "Use the Pomodoro Technique: 25 minutes of focused work, then a 5-minute break.",
                "Start each day by listing your top 3 most important tasks.",
                "Keyboard shortcuts can save you hours per week. Learn 3 new ones today.",
                "Batch similar tasks together to minimize context-switching overhead.",
                "The two-minute rule: if it takes under 2 minutes, do it now.",
                "Turn off all notifications during deep work sessions.",
                "Stand up and stretch every 45 minutes — your back and brain will thank you.",
                "Review your progress every Friday and plan the next week on Sunday.",
            ]
            return ("💡 " + random.choice(tips), "tip")

        # ── Greetings ────────────────────────────────────────────────────────
        if re.match(r'^(hi|hello|hey|yo|howdy|greet)', t):
            h = now.hour
            greeting = "Good morning" if h < 12 else "Good afternoon" if h < 18 else "Good evening"
            return (f"{greeting}! J.A.R.V.I.S. is fully operational and at your service.", "greet")

        # ── Identity ─────────────────────────────────────────────────────────
        if any(w in t for w in ['who are you', 'what are you', 'your name', 'introduce yourself']):
            return (
                "I am J.A.R.V.I.S. — Just A Rather Very Intelligent System. "
                "I am your personal AI assistant, capable of voice commands, web search, "
                "system monitoring, calculations, opening applications, and much more. "
                "How may I assist you today?",
                "info"
            )

        if any(w in t for w in ['what can you do', 'help', 'commands', 'capabilities', 'features']):
            return (
                "JARVIS CAPABILITIES:\n"
                "• Voice commands & text input\n"
                "• Time, date & calendar\n"
                "• Math & calculations\n"
                "• Open apps (Notepad, Calculator, Terminal...)\n"
                "• Open websites (Google, YouTube, GitHub...)\n"
                "• Web search & YouTube search\n"
                "• Wikipedia lookups\n"
                "• Weather reports\n"
                "• System monitoring (CPU, RAM, Disk)\n"
                "• Latest news\n"
                "• Jokes & productivity tips\n"
                "• Screenshot & volume info\n"
                "• Clipboard operations",
                "help"
            )

        # ── Screenshots ──────────────────────────────────────────────────────
        if 'screenshot' in t:
            try:
                from PIL import ImageGrab
                ts = now.strftime('%Y%m%d_%H%M%S')
                path = os.path.join(os.path.expanduser('~'), f'jarvis_screenshot_{ts}.png')
                img = ImageGrab.grab()
                img.save(path)
                return (f"Screenshot saved to: {path}", "action")
            except ImportError:
                return ("Screenshot requires Pillow. Run: pip install Pillow", "error")
            except Exception as e:
                return (f"Screenshot failed: {str(e)}", "error")

        # ── Clipboard ────────────────────────────────────────────────────────
        if 'clipboard' in t or 'copy last' in t:
            return ("CLIPBOARD_COPY", "clipboard")

        # ── Goodbye ──────────────────────────────────────────────────────────
        if any(w in t for w in ['bye', 'goodbye', 'exit', 'quit', 'shutdown', 'close', 'farewell']):
            return ("Shutting down all systems. Goodbye. Stay extraordinary.", "exit")

        # ── Thanks ───────────────────────────────────────────────────────────
        if re.search(r'thank(s| you)', t):
            return ("Always a pleasure. That is what I am here for.", "info")

        # ── Default ──────────────────────────────────────────────────────────
        webbrowser.open(f"https://www.google.com/search?q={text.replace(' ', '+')}")
        return (f'I searched Google for: "{text}". Opening results in your browser.', "search")


# ══════════════════════════════════════════════════════════════════════════════
#  HUD CANVAS — Animated Iron Man style display
# ══════════════════════════════════════════════════════════════════════════════
class HUDCanvas(tk.Canvas):
    def __init__(self, parent, **kwargs):
        super().__init__(parent, **kwargs)
        self.angle = 0
        self.pulse = 0
        self.listening = False
        self.active = True
        self._animate()

    def _animate(self):
        if not self.active:
            return
        try:
            self.delete("hud")
            self.angle = (self.angle + 1.2) % 360
            self.pulse = (self.pulse + 0.05) % (2 * math.pi)

            w = self.winfo_width() or 220
            h = self.winfo_height() or 220
            cx, cy = w // 2, h // 2
            r = min(w, h) // 2 - 10

            # Outer glow ring
            glow_r = r + 4 + math.sin(self.pulse) * 3
            for i in range(3, 0, -1):
                alpha_hex = ['20', '14', '0a'][i-1]
                self.create_oval(cx - glow_r - i*2, cy - glow_r - i*2,
                                 cx + glow_r + i*2, cy + glow_r + i*2,
                                 outline=f"#00{alpha_hex}{alpha_hex}ff", width=1, tags="hud")

            # Outer ring
            self.create_oval(cx - r, cy - r, cx + r, cy + r,
                             outline=ACCENT, width=1, tags="hud")

            # Rotating arc
            arc_start = self.angle
            self.create_arc(cx - r, cy - r, cx + r, cy + r,
                            start=arc_start, extent=110,
                            outline=ACCENT, width=2, style=tk.ARC, tags="hud")
            self.create_arc(cx - r, cy - r, cx + r, cy + r,
                            start=arc_start + 180, extent=60,
                            outline=ACCENT2, width=1, style=tk.ARC, tags="hud")

            # Inner ring
            r2 = r - 16
            self.create_oval(cx - r2, cy - r2, cx + r2, cy + r2,
                             outline=BORDER, width=1, tags="hud")

            # Counter-rotating arc inner
            self.create_arc(cx - r2, cy - r2, cx + r2, cy + r2,
                            start=-self.angle * 0.7, extent=80,
                            outline=ACCENT2, width=1, style=tk.ARC, tags="hud")

            # Core circle
            r3 = r2 - 20
            pulse_extra = math.sin(self.pulse * 2) * 3
            core_color = "#00ff88" if self.listening else ACCENT
            # Core glow
            for i in range(4, 0, -1):
                self.create_oval(cx - r3 - i*3 + pulse_extra,
                                 cy - r3 - i*3 + pulse_extra,
                                 cx + r3 + i*3 - pulse_extra,
                                 cy + r3 + i*3 - pulse_extra,
                                 fill="", outline=core_color + "15", tags="hud")
            self.create_oval(cx - r3 + pulse_extra, cy - r3 + pulse_extra,
                             cx + r3 - pulse_extra, cy + r3 - pulse_extra,
                             fill=PANEL, outline=core_color, width=2, tags="hud")

            # J text in core
            self.create_text(cx, cy - 8, text="J", font=("Consolas", 28, "bold"),
                             fill=core_color, tags="hud")
            self.create_text(cx, cy + 14, text="A.R.V.I.S", font=("Consolas", 6),
                             fill=TEXT_DIM, tags="hud")

            # Tick marks on outer ring
            for i in range(36):
                angle_rad = math.radians(i * 10)
                tick_r_outer = r - 2
                tick_r_inner = r - (8 if i % 3 == 0 else 5)
                x1 = cx + tick_r_outer * math.cos(angle_rad)
                y1 = cy + tick_r_outer * math.sin(angle_rad)
                x2 = cx + tick_r_inner * math.cos(angle_rad)
                y2 = cy + tick_r_inner * math.sin(angle_rad)
                color = ACCENT if i % 9 == 0 else ACCENT_DIM
                self.create_line(x1, y1, x2, y2, fill=color, width=1, tags="hud")

            # Corner brackets (HUD style)
            br = 8
            for ox, oy, dx, dy in [(-1, -1, 1, 1), (1, -1, -1, 1), (-1, 1, 1, -1), (1, 1, -1, -1)]:
                bx = cx + ox * (r + 10)
                by = cy + oy * (r + 10)
                self.create_line(bx, by, bx + dx*br, by, fill=ACCENT, width=2, tags="hud")
                self.create_line(bx, by, bx, by + dy*br, fill=ACCENT, width=2, tags="hud")

        except tk.TclError:
            pass

        self.after(16, self._animate)  # ~60fps


# ══════════════════════════════════════════════════════════════════════════════
#  SYSTEM MONITOR WIDGET
# ══════════════════════════════════════════════════════════════════════════════
class SystemMonitor(tk.Frame):
    def __init__(self, parent, **kwargs):
        super().__init__(parent, **kwargs)
        self.configure(bg=PANEL)
        self._build()
        self._update()

    def _build(self):
        self.bars = {}
        self.labels = {}
        metrics = [
            ("CPU", "cpu"),
            ("RAM", "ram"),
            ("DISK", "disk"),
        ]
        for i, (label, key) in enumerate(metrics):
            # Label row
            row = tk.Frame(self, bg=PANEL)
            row.pack(fill=tk.X, padx=8, pady=2)
            tk.Label(row, text=label, font=FONT_SUB, fg=TEXT_DIM, bg=PANEL,
                     width=5, anchor='w').pack(side=tk.LEFT)
            val_lbl = tk.Label(row, text="—%", font=FONT_SUB, fg=ACCENT, bg=PANEL, width=6, anchor='e')
            val_lbl.pack(side=tk.RIGHT)
            self.labels[key] = val_lbl

            # Bar
            bar_bg = tk.Frame(self, bg=ACCENT_DIM, height=3)
            bar_bg.pack(fill=tk.X, padx=8, pady=(0, 4))
            bar_fill = tk.Frame(bar_bg, bg=ACCENT, height=3)
            bar_fill.place(x=0, y=0, relheight=1, width=0)
            self.bars[key] = (bar_bg, bar_fill)

    def _update(self):
        if not PSUTIL_AVAILABLE:
            return
        try:
            cpu = psutil.cpu_percent(interval=None)
            ram = psutil.virtual_memory().percent
            disk = psutil.disk_usage('/').percent

            for key, val in [("cpu", cpu), ("ram", ram), ("disk", disk)]:
                self.labels[key].config(text=f"{val:.0f}%")
                bg_w = self.bars[key][0].winfo_width() or 100
                fill_w = int(bg_w * val / 100)
                color = GREEN if val < 60 else YELLOW if val < 85 else RED
                self.bars[key][1].config(bg=color)
                self.bars[key][1].place(width=fill_w)
        except Exception:
            pass
        self.after(1500, self._update)


# ══════════════════════════════════════════════════════════════════════════════
#  MAIN APPLICATION
# ══════════════════════════════════════════════════════════════════════════════
class JarvisApp:
    def __init__(self):
        self.brain = JarvisBrain()
        self.root = tk.Tk()
        self._setup_window()
        self._build_ui()
        self._start_clock()
        self._greet()

    def _setup_window(self):
        self.root.title("J.A.R.V.I.S. — Just A Rather Very Intelligent System")
        self.root.configure(bg=BG)
        self.root.geometry("1100x780")
        self.root.minsize(900, 650)
        # Center window
        self.root.update_idletasks()
        x = (self.root.winfo_screenwidth() - 1100) // 2
        y = (self.root.winfo_screenheight() - 780) // 2
        self.root.geometry(f"1100x780+{x}+{y}")
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)

    def _build_ui(self):
        # ── Scanline overlay effect via background pattern ───────────────────
        # Top header bar
        header = tk.Frame(self.root, bg=BG2, height=56, bd=0)
        header.pack(fill=tk.X, side=tk.TOP)
        header.pack_propagate(False)

        # Header left — logo
        logo_frame = tk.Frame(header, bg=BG2)
        logo_frame.pack(side=tk.LEFT, padx=20)
        tk.Label(logo_frame, text="◈ J.A.R.V.I.S.", font=("Consolas", 16, "bold"),
                 fg=ACCENT, bg=BG2).pack(side=tk.LEFT, pady=14)
        tk.Label(logo_frame, text="  JUST A RATHER VERY INTELLIGENT SYSTEM",
                 font=FONT_SUB, fg=TEXT_MUTED, bg=BG2).pack(side=tk.LEFT, pady=14)

        # Header right — clock
        self.clock_var = tk.StringVar(value="00:00:00")
        self.date_var = tk.StringVar(value="")
        right_frame = tk.Frame(header, bg=BG2)
        right_frame.pack(side=tk.RIGHT, padx=20)
        tk.Label(right_frame, textvariable=self.clock_var, font=("Consolas", 18, "bold"),
                 fg=ACCENT, bg=BG2).pack(side=tk.RIGHT)
        tk.Label(right_frame, textvariable=self.date_var, font=FONT_SUB,
                 fg=TEXT_DIM, bg=BG2).pack(side=tk.RIGHT, padx=12)

        # Header separator
        sep = tk.Frame(self.root, bg=ACCENT, height=1)
        sep.pack(fill=tk.X)

        # ── Main content area ────────────────────────────────────────────────
        main = tk.Frame(self.root, bg=BG)
        main.pack(fill=tk.BOTH, expand=True, padx=0, pady=0)

        # Left panel
        left = tk.Frame(main, bg=BG2, width=240, bd=0)
        left.pack(side=tk.LEFT, fill=tk.Y)
        left.pack_propagate(False)

        # Left border
        tk.Frame(main, bg=BORDER, width=1).pack(side=tk.LEFT, fill=tk.Y)

        # Right content
        right = tk.Frame(main, bg=BG)
        right.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        # ── LEFT PANEL ───────────────────────────────────────────────────────
        # HUD orb
        hud_label = tk.Frame(left, bg=BG2)
        hud_label.pack(fill=tk.X, padx=10, pady=(16, 0))
        tk.Label(hud_label, text="◇ CORE", font=FONT_SUB, fg=TEXT_MUTED, bg=BG2).pack(side=tk.LEFT)

        self.hud = HUDCanvas(left, width=220, height=220, bg=BG2,
                             highlightthickness=0, bd=0)
        self.hud.pack(pady=(4, 0))

        # Status indicator
        self.status_var = tk.StringVar(value="■ STANDBY")
        self.status_lbl = tk.Label(left, textvariable=self.status_var,
                                   font=FONT_SUB, fg=YELLOW, bg=BG2)
        self.status_lbl.pack(pady=4)

        # Separator
        tk.Frame(left, bg=BORDER, height=1).pack(fill=tk.X, padx=12, pady=8)

        # System monitor
        sys_header = tk.Frame(left, bg=BG2)
        sys_header.pack(fill=tk.X, padx=10)
        tk.Label(sys_header, text="◇ SYSTEM VITALS", font=FONT_SUB, fg=TEXT_MUTED, bg=BG2).pack(side=tk.LEFT)
        self.sys_monitor = SystemMonitor(left, bg=PANEL)
        self.sys_monitor.pack(fill=tk.X, padx=10, pady=4)

        # Separator
        tk.Frame(left, bg=BORDER, height=1).pack(fill=tk.X, padx=12, pady=8)

        # Quick action buttons
        qa_header = tk.Frame(left, bg=BG2)
        qa_header.pack(fill=tk.X, padx=10)
        tk.Label(qa_header, text="◇ QUICK ACCESS", font=FONT_SUB, fg=TEXT_MUTED, bg=BG2).pack(side=tk.LEFT)

        quick_cmds = [
            ("⏱  Time & Date", "what time is it"),
            ("🌐  Open Google", "open google"),
            ("▶  Open YouTube", "open youtube"),
            ("📊  System Status", "system status"),
            ("💡  Productivity Tip", "give me a tip"),
            ("😄  Tell a Joke", "tell me a joke"),
            ("📋  Help & Commands", "what can you do"),
        ]

        for label, cmd in quick_cmds:
            btn = tk.Button(left, text=label, font=FONT_SUB, fg=TEXT_DIM, bg=PANEL,
                            activeforeground=ACCENT, activebackground=BG2,
                            bd=0, padx=8, pady=5, anchor='w',
                            cursor='hand2',
                            command=lambda c=cmd: self._handle_input(c))
            btn.pack(fill=tk.X, padx=10, pady=1)
            btn.bind("<Enter>", lambda e, b=btn: b.config(fg=ACCENT, bg=ACCENT_DIM))
            btn.bind("<Leave>", lambda e, b=btn: b.config(fg=TEXT_DIM, bg=PANEL))

        # ── RIGHT PANEL ──────────────────────────────────────────────────────
        # Chat header
        chat_header = tk.Frame(right, bg=BG, pady=10)
        chat_header.pack(fill=tk.X, padx=16)
        tk.Label(chat_header, text="◈ INTERFACE LOG", font=FONT_SUB,
                 fg=TEXT_MUTED, bg=BG).pack(side=tk.LEFT)
        self.msg_count_var = tk.StringVar(value="0 ENTRIES")
        tk.Label(chat_header, textvariable=self.msg_count_var, font=FONT_SUB,
                 fg=TEXT_MUTED, bg=BG).pack(side=tk.RIGHT)

        # Chat area with custom scrollbar
        chat_container = tk.Frame(right, bg=BORDER, bd=0)
        chat_container.pack(fill=tk.BOTH, expand=True, padx=16, pady=(0, 8))

        chat_inner = tk.Frame(chat_container, bg=BG2, bd=0)
        chat_inner.pack(fill=tk.BOTH, expand=True, padx=1, pady=1)

        self.chat_text = tk.Text(
            chat_inner,
            font=FONT_CHAT,
            bg=BG2, fg=TEXT,
            insertbackground=ACCENT,
            selectbackground=ACCENT_DIM,
            selectforeground=TEXT,
            bd=0, padx=12, pady=12,
            wrap=tk.WORD,
            state=tk.DISABLED,
            cursor="arrow",
        )
        scrollbar = tk.Scrollbar(chat_inner, command=self.chat_text.yview,
                                 bg=PANEL, troughcolor=BG2,
                                 activebackground=ACCENT_DIM, width=8)
        self.chat_text.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.chat_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        # Configure text tags
        self.chat_text.tag_configure("time", foreground=TEXT_MUTED, font=FONT_SUB)
        self.chat_text.tag_configure("user_label", foreground=YELLOW, font=("Consolas", 9, "bold"))
        self.chat_text.tag_configure("user_text", foreground=TEXT)
        self.chat_text.tag_configure("jarvis_label", foreground=ACCENT, font=("Consolas", 9, "bold"))
        self.chat_text.tag_configure("jarvis_text", foreground=TEXT)
        self.chat_text.tag_configure("error_text", foreground=RED)
        self.chat_text.tag_configure("action_text", foreground=GREEN)
        self.chat_text.tag_configure("system_text", foreground=YELLOW)
        self.chat_text.tag_configure("calc_text", foreground=ACCENT)
        self.chat_text.tag_configure("divider", foreground=TEXT_MUTED)
        self.chat_text.tag_configure("tip_text", foreground="#ffcc44")
        self.chat_text.tag_configure("wiki_text", foreground="#88ddff")

        # ── Input area ───────────────────────────────────────────────────────
        input_border = tk.Frame(right, bg=BORDER, height=1)
        input_border.pack(fill=tk.X, padx=16)

        input_area = tk.Frame(right, bg=BG, pady=10)
        input_area.pack(fill=tk.X, padx=16)

        # Live transcript / status label
        self.input_status = tk.StringVar(value="")
        tk.Label(input_area, textvariable=self.input_status, font=FONT_SUB,
                 fg=GREEN, bg=BG).pack(anchor='w', pady=(0, 4))

        # Input row
        input_row = tk.Frame(input_area, bg=BG)
        input_row.pack(fill=tk.X)

        # Prompt symbol
        tk.Label(input_row, text="▷", font=("Consolas", 14), fg=ACCENT, bg=BG).pack(side=tk.LEFT)

        # Text entry
        self.entry_var = tk.StringVar()
        self.entry = tk.Entry(
            input_row,
            textvariable=self.entry_var,
            font=FONT_MONO,
            bg=PANEL, fg=TEXT,
            insertbackground=ACCENT,
            selectbackground=ACCENT_DIM,
            bd=0, relief=tk.FLAT,
            highlightthickness=1,
            highlightbackground=BORDER,
            highlightcolor=ACCENT,
        )
        self.entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=8, ipady=8)
        self.entry.bind("<Return>", lambda e: self._on_send())
        self.entry.bind("<Up>", self._history_up)
        self.entry.bind("<Down>", self._history_down)
        self.entry.focus_set()

        # Buttons
        btn_style = dict(font=FONT_SUB, bd=0, padx=14, pady=8, cursor='hand2', relief=tk.FLAT)

        self.mic_btn = tk.Button(input_row, text="🎤 VOICE",
                                 fg=GREEN, bg=PANEL, activeforeground=BG, activebackground=GREEN,
                                 command=self._on_voice, **btn_style)
        self.mic_btn.pack(side=tk.LEFT, padx=4)

        send_btn = tk.Button(input_row, text="SEND ▶",
                             fg=ACCENT, bg=PANEL, activeforeground=BG, activebackground=ACCENT,
                             command=self._on_send, **btn_style)
        send_btn.pack(side=tk.LEFT, padx=4)

        stop_btn = tk.Button(input_row, text="■ STOP",
                             fg=RED, bg=PANEL, activeforeground=BG, activebackground=RED,
                             command=self._on_stop, **btn_style)
        stop_btn.pack(side=tk.LEFT, padx=4)

        clear_btn = tk.Button(input_row, text="⌫ CLEAR",
                              fg=TEXT_DIM, bg=PANEL, activeforeground=TEXT, activebackground=BORDER,
                              command=self._on_clear, **btn_style)
        clear_btn.pack(side=tk.LEFT, padx=4)

        # Bottom status bar
        bottom = tk.Frame(self.root, bg=BG2, height=24)
        bottom.pack(fill=tk.X, side=tk.BOTTOM)
        bottom.pack_propagate(False)
        tk.Frame(self.root, bg=ACCENT, height=1).pack(fill=tk.X, side=tk.BOTTOM)

        self.bottom_status = tk.StringVar(value="JARVIS ONLINE  ■  ALL SYSTEMS NOMINAL  ■  AWAITING COMMAND")
        tk.Label(bottom, textvariable=self.bottom_status, font=FONT_SUB,
                 fg=TEXT_MUTED, bg=BG2).pack(side=tk.LEFT, padx=12, pady=4)

        tts_text = "TTS: ACTIVE" if TTS_AVAILABLE else "TTS: UNAVAILABLE"
        sr_text = "SR: ACTIVE" if SR_AVAILABLE else "SR: UNAVAILABLE"
        tk.Label(bottom, text=f"  {sr_text}  ■  {tts_text}",
                 font=FONT_SUB, fg=TEXT_MUTED, bg=BG2).pack(side=tk.RIGHT, padx=12)

        # Input history
        self.input_history = []
        self.history_idx = -1
        self.msg_count = 0

    # ── Clock ─────────────────────────────────────────────────────────────────
    def _start_clock(self):
        def _tick():
            now = datetime.datetime.now()
            self.clock_var.set(now.strftime("%H:%M:%S"))
            self.date_var.set(now.strftime("%a %d %b %Y"))
            self.root.after(1000, _tick)
        _tick()

    # ── Greet ─────────────────────────────────────────────────────────────────
    def _greet(self):
        self.root.after(500, lambda: self._add_jarvis_message(
            "All systems online. J.A.R.V.I.S. is fully operational.\n"
            "Voice recognition and text-to-speech initialized.\n"
            "Type a command or press VOICE to speak. Say 'help' for a full list of capabilities.",
            "info"
        ))
        self.root.after(800, lambda: self.brain.speak(
            "Good day. J.A.R.V.I.S. is fully online and ready for your command."
        ))

    # ── Message rendering ─────────────────────────────────────────────────────
    def _add_user_message(self, text):
        self.chat_text.config(state=tk.NORMAL)
        ts = datetime.datetime.now().strftime("%H:%M:%S")
        self.chat_text.insert(tk.END, f"  [{ts}]  ", "time")
        self.chat_text.insert(tk.END, "YOU  ", "user_label")
        self.chat_text.insert(tk.END, text + "\n", "user_text")
        self.chat_text.config(state=tk.DISABLED)
        self.chat_text.see(tk.END)

    def _add_jarvis_message(self, text, msg_type="info"):
        self.chat_text.config(state=tk.NORMAL)
        ts = datetime.datetime.now().strftime("%H:%M:%S")
        self.chat_text.insert(tk.END, f"  [{ts}]  ", "time")
        self.chat_text.insert(tk.END, "JARVIS  ", "jarvis_label")

        tag_map = {
            "error": "error_text",
            "action": "action_text",
            "system": "system_text",
            "calc": "calc_text",
            "tip": "tip_text",
            "wiki": "wiki_text",
            "help": "action_text",
        }
        tag = tag_map.get(msg_type, "jarvis_text")
        self.chat_text.insert(tk.END, text + "\n", tag)
        self.chat_text.insert(tk.END, "  " + "─" * 60 + "\n", "divider")
        self.chat_text.config(state=tk.DISABLED)
        self.chat_text.see(tk.END)
        self.msg_count += 1
        self.msg_count_var.set(f"{self.msg_count} ENTRIES")

    def _add_system_line(self, text):
        self.chat_text.config(state=tk.NORMAL)
        self.chat_text.insert(tk.END, f"  ⚡ {text}\n", "system_text")
        self.chat_text.config(state=tk.DISABLED)
        self.chat_text.see(tk.END)

    # ── Input handling ────────────────────────────────────────────────────────
    def _on_send(self):
        text = self.entry_var.get().strip()
        if not text:
            return
        self.entry_var.set("")
        self.input_history.append(text)
        self.history_idx = len(self.input_history)
        self._handle_input(text)

    def _handle_input(self, text):
        self._add_user_message(text)
        self._set_status("■ PROCESSING", YELLOW)

        def _process():
            response, msg_type = self.brain.process(text)

            # Special actions
            if response == "CLIPBOARD_COPY":
                # Copy last JARVIS message to clipboard
                self.root.clipboard_clear()
                self.root.clipboard_append(self.brain.conversation_history[-1] if self.brain.conversation_history else "")
                response = "Last response copied to clipboard."
                msg_type = "action"

            if msg_type == "exit":
                self.root.after(0, lambda: self._add_jarvis_message(response, msg_type))
                self.brain.speak(response)
                time.sleep(2)
                self.root.after(0, self.root.destroy)
                return

            self.brain.conversation_history.append(response)
            self.root.after(0, lambda: self._add_jarvis_message(response, msg_type))
            self.root.after(0, lambda: self._set_status("■ READY", GREEN))

            if self.brain.voice_enabled:
                # Don't speak long help text fully
                speak_text = response if len(response) < 300 else response[:200] + "..."
                self.brain.speak(speak_text)

        threading.Thread(target=_process, daemon=True).start()

    def _on_voice(self):
        if not SR_AVAILABLE:
            self._add_system_line("SpeechRecognition not installed. Run: pip install SpeechRecognition pyaudio")
            return

        self._set_status("🎤 LISTENING...", GREEN)
        self.hud.listening = True
        self.mic_btn.config(state=tk.DISABLED, text="🎤 ACTIVE")
        self.input_status.set("🎤 Speak now...")

        def _partial(msg):
            self.root.after(0, lambda: self.input_status.set(f"◈ {msg}"))

        def _final(text):
            self.root.after(0, lambda: self._finish_voice(text))

        def _error(msg):
            self.root.after(0, lambda: self._voice_error(msg))

        self.brain.listen(_partial, _final, _error)

    def _finish_voice(self, text):
        self.input_status.set("")
        self.hud.listening = False
        self.mic_btn.config(state=tk.NORMAL, text="🎤 VOICE")
        self._set_status("■ READY", GREEN)
        self._handle_input(text)

    def _voice_error(self, msg):
        self.input_status.set("")
        self.hud.listening = False
        self.mic_btn.config(state=tk.NORMAL, text="🎤 VOICE")
        self._set_status("■ STANDBY", YELLOW)
        self._add_system_line(msg)

    def _on_stop(self):
        self.brain.stop_speaking()
        self._add_system_line("Speech stopped.")

    def _on_clear(self):
        self.chat_text.config(state=tk.NORMAL)
        self.chat_text.delete(1.0, tk.END)
        self.chat_text.config(state=tk.DISABLED)
        self.msg_count = 0
        self.msg_count_var.set("0 ENTRIES")
        self._add_system_line("Interface log cleared.")

    def _set_status(self, text, color=YELLOW):
        self.status_var.set(text)
        self.status_lbl.config(fg=color)
        self.bottom_status.set(f"JARVIS  ■  {text.replace('■ ', '')}  ■  {datetime.datetime.now().strftime('%H:%M:%S')}")

    def _history_up(self, event):
        if self.input_history and self.history_idx > 0:
            self.history_idx -= 1
            self.entry_var.set(self.input_history[self.history_idx])
            self.entry.icursor(tk.END)

    def _history_down(self, event):
        if self.history_idx < len(self.input_history) - 1:
            self.history_idx += 1
            self.entry_var.set(self.input_history[self.history_idx])
        else:
            self.history_idx = len(self.input_history)
            self.entry_var.set("")

    def _on_close(self):
        self.hud.active = False
        self.brain.stop_speaking()
        self.root.destroy()

    def run(self):
        self._set_status("■ ONLINE", GREEN)
        self.root.mainloop()


# ══════════════════════════════════════════════════════════════════════════════
if __name__ == "__main__":
    app = JarvisApp()
    app.run()
